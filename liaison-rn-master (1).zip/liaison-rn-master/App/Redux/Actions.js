import { bindActionCreators } from 'redux'
import StartupActions from './StartupRedux'
import AuthActions from './AuthRedux'
export {
  bindActionCreators,
  StartupActions,
  AuthActions
}
