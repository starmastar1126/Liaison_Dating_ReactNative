# Lib

At first glance, this could appear to be a "miscellaneous" folder, but we recommend that you treat this as proving ground for components that could be reusable outside your project.

Maybe you're writing a set of utilities that you could use outside your project, but they're not quite ready or battle tested.  This folder would be a great place to put them.  They ideally be pure functions have no dependencies on other things in your App folder.
