export default {
  useFixtures: false,
  ezLogin: false,
  yellowBox: false,
  reduxLogging: __DEV__,
  includeExamples: false,
  useReactotron: false
}
