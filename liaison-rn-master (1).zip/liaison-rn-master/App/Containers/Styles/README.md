### Styles Folder
Container styles are separated from functionality.
